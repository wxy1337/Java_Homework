package lib;

//�������
public class Client {
 
    public static void main(String[] args) {
        
        new UserManager().start();
    }
 
}